﻿using System;
using System.Text;

namespace buoi14
{
    public class buoi14
    {
        public static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            //StudentTest._StudentTest();
            TeacherTest._TeacherTest();
        }
    }
}
